/** @type {import('tailwindcss').Config} */
export default {
  content: [
    "./index.html",
    "./src/**/*.{js,ts,jsx,tsx}",
  ],
  theme: {
    extend: {
      fontFamily: {
        playfair: ['"Playfair Display"', 'serif'],
        poppins: ['Poppins', 'sans-serif'],
      },
      colors: {
        primary: '#c19a6b',
        secondary: '#3d2b1f',
        light: '#f8f5f2',
        dark: '#222',
      },
    },
  },
  plugins: [],
}

import { useRestaurant } from '../../contexts/RestaurantContext';
import { useCart } from '../../contexts/CartContext';

const WorldDishes = () => {
  const { worldDishes, isLoading } = useRestaurant();
  const { addToCart } = useCart();

  if (isLoading) return <div className="text-center py-8">Loading world dishes...</div>;

  return (
    <section className="py-12 bg-white">
      <div className="container mx-auto px-4">
        <h2 className="font-playfair text-3xl md:text-4xl font-bold text-center mb-4">World Famous Dishes</h2>
        <div className="w-20 h-1 bg-amber-600 mx-auto mb-8"></div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {worldDishes.map((dish) => (
            <div 
              key={dish.id} 
              className="bg-white rounded-lg overflow-hidden shadow-md hover:shadow-lg transition transform hover:-translate-y-1"
            >
              <div className="relative h-48 overflow-hidden">
                <img 
                  src={dish.image} 
                  alt={dish.name} 
                  className="w-full h-full object-cover transition duration-500 hover:scale-110"
                />
                <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black to-transparent p-4">
                  <h3 className="text-white font-bold">{dish.country}</h3>
                </div>
              </div>
              <div className="p-4">
                <h4 className="font-bold text-lg mb-2">{dish.name}</h4>
                <p className="text-gray-600 text-sm mb-3">{dish.description}</p>
                <div className="flex justify-between items-center">
                  <span className="text-amber-600 font-bold">${dish.price.toFixed(2)}</span>
                  <button 
                    onClick={() => addToCart(dish)}
                    className="bg-amber-600 hover:bg-amber-700 text-white px-3 py-1 rounded-md text-sm font-medium transition"
                  >
                    Add to Order
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default WorldDishes;

import { useState } from 'react';
import { Link } from 'react-router-dom';
import { FaBars, FaTimes } from 'react-icons/fa';

const Header = () => {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  return (
    <header className="fixed w-full bg-white shadow-md z-40 py-3">
      <div className="container mx-auto px-4 flex justify-between items-center">
        <Link to="/" className="text-2xl font-bold font-playfair text-gray-800">
          Global <span className="text-amber-600">Bites</span>
        </Link>
        
        {/* Desktop Navigation */}
        <nav className="hidden md:flex space-x-8">
          <Link to="/" className="font-medium hover:text-amber-600 transition">Home</Link>
          <Link to="/menu" className="font-medium hover:text-amber-600 transition">Menu</Link>
          <Link to="/about" className="font-medium hover:text-amber-600 transition">About</Link>
          <Link to="/reservations" className="font-medium hover:text-amber-600 transition">Reservations</Link>
          <Link to="/contact" className="font-medium hover:text-amber-600 transition">Contact</Link>
        </nav>
        
        <div className="hidden md:block">
          <Link 
            to="/reservations" 
            className="bg-amber-600 hover:bg-transparent hover:text-amber-600 hover:border-amber-600 border-2 border-amber-600 text-white px-6 py-2 rounded-md font-medium transition"
          >
            Book Table
          </Link>
        </div>
        
        {/* Mobile Menu Button */}
        <button 
          className="md:hidden text-2xl focus:outline-none"
          onClick={() => setMobileMenuOpen(true)}
        >
          <FaBars />
        </button>
      </div>
      
      {/* Mobile Menu */}
      {mobileMenuOpen && (
        <div className="fixed inset-0 bg-black bg-opacity-50 z-50 md:hidden">
          <div className="absolute top-0 right-0 w-64 h-full bg-white shadow-lg p-4">
            <div className="flex justify-end">
              <button 
                className="text-2xl focus:outline-none"
                onClick={() => setMobileMenuOpen(false)}
              >
                <FaTimes />
              </button>
            </div>
            <nav className="flex flex-col space-y-4 mt-8">
              <Link to="/" className="font-medium hover:text-amber-600 transition" onClick={() => setMobileMenuOpen(false)}>Home</Link>
              <Link to="/menu" className="font-medium hover:text-amber-600 transition" onClick={() => setMobileMenuOpen(false)}>Menu</Link>
              <Link to="/about" className="font-medium hover:text-amber-600 transition" onClick={() => setMobileMenuOpen(false)}>About</Link>
              <Link to="/reservations" className="font-medium hover:text-amber-600 transition" onClick={() => setMobileMenuOpen(false)}>Reservations</Link>
              <Link to="/contact" className="font-medium hover:text-amber-600 transition" onClick={() => setMobileMenuOpen(false)}>Contact</Link>
            </nav>
          </div>
        </div>
      )}
    </header>
  );
};

export default Header;

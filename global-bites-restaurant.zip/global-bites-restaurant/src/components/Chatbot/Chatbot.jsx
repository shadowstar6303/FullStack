import { useState, useEffect, useRef } from 'react';
import { useChatbot } from '../../contexts/ChatbotContext';
import { FaPaperPlane, FaMinus, FaTimes } from 'react-icons/fa';

const Chatbot = () => {
  const { isOpen, toggleChatbot, minimizeChatbot, closeChatbot, messages, sendMessage } = useChatbot();
  const [inputMessage, setInputMessage] = useState('');
  const messagesEndRef = useRef(null);

  const quickReplies = [
    "What are your hours?",
    "How do I make a reservation?",
    "What's on your menu?",
    "Where are you located?"
  ];

  const handleSendMessage = () => {
    if (inputMessage.trim()) {
      sendMessage(inputMessage);
      setInputMessage('');
    }
  };

  const handleKeyPress = (e) => {
    if (e.key === 'Enter') {
      handleSendMessage();
    }
  };

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  if (!isOpen) return null;

  return (
    <div className="fixed bottom-4 right-4 w-80 bg-white rounded-lg shadow-xl z-50 overflow-hidden">
      <div 
        className="bg-amber-600 text-white p-3 flex justify-between items-center cursor-pointer"
        onClick={toggleChatbot}
      >
        <h3 className="font-bold">Global Bites Assistant</h3>
        <div className="flex space-x-2">
          <button onClick={(e) => { e.stopPropagation(); minimizeChatbot(); }}>
            <FaMinus />
          </button>
          <button onClick={(e) => { e.stopPropagation(); closeChatbot(); }}>
            <FaTimes />
          </button>
        </div>
      </div>

      <div className="h-80 overflow-y-auto p-4 bg-gray-50">
        {messages.map((msg, index) => (
          <div 
            key={index} 
            className={}
          >
            <div 
              className={}
            >
              <p>{msg.text}</p>
              <p className="text-xs mt-1 opacity-70">
                {msg.timestamp}
              </p>
            </div>
          </div>
        ))}
        <div ref={messagesEndRef} />
      </div>

      <div className="p-3 border-t border-gray-200">
        <div className="flex mb-2 space-x-1 overflow-x-auto">
          {quickReplies.map((reply, index) => (
            <button
              key={index}
              onClick={() => {
                setInputMessage(reply);
                handleSendMessage();
              }}
              className="whitespace-nowrap text-xs bg-gray-100 hover:bg-gray-200 px-2 py-1 rounded-full"
            >
              {reply}
            </button>
          ))}
        </div>
        <div className="flex">
          <input
            type="text"
            value={inputMessage}
            onChange={(e) => setInputMessage(e.target.value)}
            onKeyPress={handleKeyPress}
            placeholder="Type your message..."
            className="flex-grow px-3 py-2 border border-gray-300 rounded-l-md focus:outline-none focus:ring-1 focus:ring-amber-500"
          />
          <button
            onClick={handleSendMessage}
            className="bg-amber-600 hover:bg-amber-700 text-white px-3 py-2 rounded-r-md"
          >
            <FaPaperPlane />
          </button>
        </div>
      </div>
    </div>
  );
};

export default Chatbot;

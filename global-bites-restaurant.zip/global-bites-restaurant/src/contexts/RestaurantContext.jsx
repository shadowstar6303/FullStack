import { createContext, useContext, useState, useEffect } from 'react';
import axios from 'axios';

const RestaurantContext = createContext();

export const RestaurantProvider = ({ children }) => {
  const [menuItems, setMenuItems] = useState([]);
  const [worldDishes, setWorldDishes] = useState([]);
  const [dailySpecial, setDailySpecial] = useState('');
  const [isLoading, setIsLoading] = useState(true);

  // Sample data - in a real app, this would come from an API
  useEffect(() => {
    const fetchData = async () => {
      try {
        // Mock data for menu items
        const mockMenuItems = [
          {
            id: 1,
            name: "Bruschetta",
            description: "Toasted bread topped with tomatoes, garlic, and fresh basil",
            price: 8.99,
            category: "starters",
            dietary: ["vegetarian"],
            image: "https://images.unsplash.com/photo-1601050690597-df0568f70950?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1470&q=80"
          },
          // More menu items...
        ];

        // Mock data for world dishes
        const mockWorldDishes = [
          {
            id: 1,
            name: "Pizza Margherita",
            description: "Classic Neapolitan pizza with tomato, mozzarella, and basil",
            price: 14.99,
            country: "Italy",
            image: "https://images.unsplash.com/photo-1590947132387-155cc02f3212?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1470&q=80"
          },
          // More world dishes...
        ];

        setMenuItems(mockMenuItems);
        setWorldDishes(mockWorldDishes);
        
        // Set daily special based on current day
        const days = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
        const today = new Date().getDay();
        const specials = {
          'Sunday': "Sunday Brunch Special - Eggs Benedict with smoked salmon and hollandaise sauce",
          'Monday': "Monday Pasta Special - Homemade fettuccine alfredo with grilled chicken",
          'Tuesday': "Taco Tuesday - Three gourmet tacos with your choice of protein",
          'Wednesday': "Wine Wednesday - 50% off all bottles of wine",
          'Thursday': "Thursday Steak Night - 12oz ribeye with two sides",
          'Friday': "Fresh Catch Friday - Today's fresh seafood selection",
          'Saturday': "Saturday Chef's Special - Ask your server about today's creation"
        };
        setDailySpecial(specials[days[today]]);
        
        setIsLoading(false);
      } catch (error) {
        console.error("Error fetching data:", error);
        setIsLoading(false);
      }
    };

    fetchData();
  }, []);

  return (
    <RestaurantContext.Provider value={{
      menuItems,
      worldDishes,
      dailySpecial,
      isLoading
    }}>
      {children}
    </RestaurantContext.Provider>
  );
};

export const useRestaurant = () => useContext(RestaurantContext);

import { createContext, useContext, useState, useEffect } from 'react';

const ChatbotContext = createContext();

export const ChatbotProvider = ({ children }) => {
  const [isOpen, setIsOpen] = useState(false);
  const [messages, setMessages] = useState([
    {
      text: "Hello! I'm your dining assistant. How can I help you today?",
      sender: 'bot',
      timestamp: getCurrentTime(),
    },
  ]);

  // Auto-open chatbot after 10 seconds
  useEffect(() => {
    const timer = setTimeout(() => {
      setIsOpen(true);
    }, 10000);

    return () => clearTimeout(timer);
  }, []);

  function getCurrentTime() {
    const now = new Date();
    return now.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
  }

  function getBotResponse(userMessage) {
    const lowerMessage = userMessage.toLowerCase();
    
    if (lowerMessage.includes('hour') || lowerMessage.includes('open')) {
      return "We're open:\nMon-Thu: 11am-10pm\nFri-Sat: 11am-11pm\nSun: 10am-9pm";
    } else if (lowerMessage.includes('reserv') || lowerMessage.includes('book')) {
      return "You can make a reservation by clicking the 'Book Table' button on our website or by calling us at (123) 456-7890.";
    } else if (lowerMessage.includes('menu') || lowerMessage.includes('dish')) {
      return "Our menu features world-famous dishes from Italy, Japan, Mexico, India, France, and more! Check out our 'World Dishes' section or full menu.";
    } else if (lowerMessage.includes('location') || lowerMessage.includes('address')) {
      return "We're located at 123 Gourmet Avenue, Foodie City. Would you like directions?";
    } else if (lowerMessage.includes('hello') || lowerMessage.includes('hi')) {
      return "Hello! How can I assist you today? You can ask about our hours, menu, or reservations.";
    } else {
      return "I'm sorry, I didn't understand that. I can help with information about our hours, menu, or reservations. What would you like to know?";
    }
  }

  const sendMessage = (text) => {
    // Add user message
    const userMessage = {
      text,
      sender: 'user',
      timestamp: getCurrentTime(),
    };
    setMessages(prev => [...prev, userMessage]);

    // Simulate typing delay
    setTimeout(() => {
      const botResponse = {
        text: getBotResponse(text),
        sender: 'bot',
        timestamp: getCurrentTime(),
      };
      setMessages(prev => [...prev, botResponse]);
    }, 1000);
  };

  const toggleChatbot = () => {
    setIsOpen(prev => !prev);
  };

  const minimizeChatbot = () => {
    setIsOpen(false);
  };

  const closeChatbot = () => {
    setIsOpen(false);
  };

  return (
    <ChatbotContext.Provider
      value={{
        isOpen,
        messages,
        sendMessage,
        toggleChatbot,
        minimizeChatbot,
        closeChatbot,
      }}
    >
      {children}
    </ChatbotContext.Provider>
  );
};

export const useChatbot = () => useContext(ChatbotContext);

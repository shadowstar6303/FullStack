import Hero from '../components/Hero/Hero';
import WorldDishes from '../components/WorldDishes/WorldDishes';
import TestimonialForm from '../components/TestimonialForm/TestimonialForm';

const Home = () => {
  return (
    <>
      <Hero />
      <WorldDishes />
      <TestimonialForm />
    </>
  );
};

export default Home;

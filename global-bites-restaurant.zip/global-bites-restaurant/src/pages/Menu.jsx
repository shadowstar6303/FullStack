import MenuFilter from '../components/MenuFilter/MenuFilter';

const Menu = () => {
  return (
    <div className="pt-24">
      <MenuFilter />
    </div>
  );
};

export default Menu;
